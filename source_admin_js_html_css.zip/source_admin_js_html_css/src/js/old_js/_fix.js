if (document.documentMode) window.MutationObserver = undefined;
