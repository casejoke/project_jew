/*
* Login 
*/
var login = {
	init:function(){

	}
}