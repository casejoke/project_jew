$(document).ready(function() {
  visual.init();
  login.init();
  help.datepickerInit();
});
$(window).on('resize', function(){
  
});
$(window).on('load', function(){
  
});
$(window).on('scroll', function(){
  
});